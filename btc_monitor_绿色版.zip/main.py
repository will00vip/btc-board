# ================================================================
# BTC插针放量反转监控系统 — 主程序
# 运行方式：python main.py
# ================================================================

import time
import sys
import os
import logging
from datetime import datetime, timezone, timedelta

from config import (
    SYMBOL, INTERVAL, CHECK_INTERVAL,
    MAX_DROP_4H_PCT, NO_SIGNAL_HOURS
)
from data_fetcher import get_klines, get_price_change_pct
from signal_detector import detect_signal, evaluate_trade_value
from notifier import send_wechat, send_all

CST = timezone(timedelta(hours=8))

# ── 日志配置 ──────────────────────────────────────────────────────
LOG_FILE = os.path.join(os.path.dirname(__file__), "monitor.log")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ]
)
logger = logging.getLogger("btc_monitor")


def is_quiet_hours() -> bool:
    now_hour = datetime.now(CST).hour
    return NO_SIGNAL_HOURS[0] <= now_hour < NO_SIGNAL_HOURS[1]


def format_signal_message(signal: dict, drop_pct: float) -> tuple[str, str]:
    """格式化微信推送内容（含交易价值评估，支持多空双向）"""
    level     = signal.get("level", "⚡信号")
    score     = signal.get("score", 0)
    rating    = signal.get("trade_rating", "")
    rr        = signal.get("trade_rr", 0)
    direction = signal.get("direction", "long")
    dir_emoji = "📈 做多" if direction == "long" else "📉 做空"
    dir_label = "插针买入" if direction == "long" else "插针卖出"

    title = f"{level}【BTC{dir_label}信号】得分{score}/10 | {rating}"

    risk_notes = signal.get("trade_risks", [])
    risk_lines = [f"  {r}" for r in risk_notes] if risk_notes else ["  ✅ 无额外风险"]

    conf_label = "低点抬高✅" if direction == "long" else "高点下降✅"
    if not signal.get("extreme_confirmed"):
        conf_label = "低点待确认⏳" if direction == "long" else "高点待确认⏳"

    lines = [
        f"🔔 {level}  {dir_emoji}  得分：{score}/10",
        f"━━━━━━━━━━━━━━━━",
        f"时间：{signal['time']}",
        f"当前价格：{signal['entry_price']:,.1f} USDT",
        f"",
        f"【🎯 值不值做？】",
        f"  {rating}（置信度：{signal.get('trade_conf','—')}）",
        f"  盈亏比：{rr}:1",
        f"  操作建议：{signal.get('trade_advice','')}",
        f"",
        f"【📐 止损止盈参考】",
        f"  止损位：{signal['stop_loss']:,.1f} USDT（插针极值{'下方' if direction=='long' else '上方'}0.2%）",
        f"  保守目标：{signal.get('trade_tp_cons',0):,.1f} USDT（盈亏比1.5:1）",
        f"  标准目标：{signal.get('trade_tp_std',0):,.1f} USDT（盈亏比2.5:1）",
        f"  激进目标：{signal.get('trade_tp_agg',0):,.1f} USDT（盈亏比4:1）",
        f"  每U风险：{signal.get('trade_risk_per',0):,.1f} USDT",
        f"",
        f"【⚠️ 风险提示】",
    ] + risk_lines + [
        f"",
        f"━━━━━━━━━━━━━━━━",
        f"📊 指标详情（得分{score}/10）",
        f"  形态：影线{signal['shadow_ratio']}倍✅  收盘{signal['close_position']}%  放量{signal['volume_ratio']}倍✅",
        f"  确认：{conf_label}",
        f"  MACD：{signal['macd_desc']}",
        f"  KDJ ：{signal['kdj_desc']}",
        f"  RSI ：{signal['rsi_desc']}",
        f"  WR  ：{signal['wr_desc']}",
        f"  BOLL：{signal['boll_desc']}",
        f"",
        f"【市场环境】4小时涨跌：{drop_pct:+.2f}%",
        f"━━━━━━━━━━━━━━━━",
        f"⚠️ 请核对SOP后再决策！",
    ]
    return title, "\n".join(lines)


def run_once() -> None:
    now_str = datetime.now(CST).strftime("%Y-%m-%d %H:%M:%S")
    logger.info(f"{'='*50}")
    logger.info(f"扫描 BTC/USDT {INTERVAL} K线...")

    df = get_klines(SYMBOL, INTERVAL, limit=50)
    if df.empty:
        logger.error("[错误] 获取K线数据失败，跳过本次扫描")
        return

    current_price = df.iloc[-1]["close"]
    logger.info(f"当前价格: {current_price:,.1f} USDT")

    if is_quiet_hours():
        logger.info(f"[静默时段] 凌晨{NO_SIGNAL_HOURS[0]}~{NO_SIGNAL_HOURS[1]}点，跳过")
        return

    drop_pct = get_price_change_pct(SYMBOL, hours=4)
    if drop_pct < -MAX_DROP_4H_PCT:
        logger.info(f"[暴跌过滤] 4小时跌幅: {drop_pct:.1f}%，超阈值，跳过")
        return
    else:
        logger.info(f"4小时涨跌: {drop_pct:+.1f}%")

    signal = detect_signal(df, drop_4h=drop_pct)

    if signal and signal.get("found"):
        score = signal.get("score", 0)
        direction = signal.get("direction", "long")
        logger.info(f"🔔 发现信号！方向:{direction} 综合得分:{score}/10 {signal.get('level','')}")
        title, content = format_signal_message(signal, drop_pct)
        logger.info(content)
        ok = send_all(title, content)
        if ok:
            logger.info(f"✅ 推送成功（微信+手机）：{title}")
        else:
            logger.warning(f"❌ 微信推送失败，请检查网络或Key配置")
    elif signal and not signal.get("found"):
        # 插针+放量满足，但指标配合不足
        score = signal.get("score", 0)
        direction = signal.get("direction", "long")
        logger.info(f"[未推送] 检测到{direction}插针形态，但综合得分{score}/10 < 5，不推送")
        logger.info(f"  MACD: {signal.get('macd_desc', '')}")
        logger.info(f"  KDJ:  {signal.get('kdj_desc', '')}")
        logger.info(f"  RSI:  {signal.get('rsi_desc', '')}")
        logger.info(f"  WR:   {signal.get('wr_desc', '')}")
        logger.info(f"  BOLL: {signal.get('boll_desc', '')}")
    else:
        logger.info("无信号")


def main():
    logger.info("=" * 50)
    logger.info("  BTC插针放量反转监控系统 v2.0")
    logger.info(f"  监控品种: {SYMBOL.upper()}")
    logger.info(f"  K线周期: {INTERVAL}")
    logger.info(f"  扫描间隔: {CHECK_INTERVAL // 60} 分钟")
    logger.info(f"  指标体系: MACD + KDJ + RSI + WR + BOLL")
    logger.info(f"  推送阈值: 综合得分 ≥ 5/10")
    logger.info("=" * 50)
    logger.info("按 Ctrl+C 停止\n")

    run_once()

    while True:
        try:
            next_time = (datetime.now(CST) + timedelta(seconds=CHECK_INTERVAL)).strftime("%H:%M:%S")
            logger.info(f"下次扫描: {next_time}")
            time.sleep(CHECK_INTERVAL)
            run_once()
        except KeyboardInterrupt:
            logger.info("\n[停止] 监控程序已手动停止")
            sys.exit(0)
        except Exception as e:
            logger.error(f"[异常] {e}，60秒后重试...")
            time.sleep(60)


if __name__ == "__main__":
    main()
