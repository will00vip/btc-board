# ================================================================
# 币安（Binance）行情数据获取模块
# 国内网络直连，无需翻墙
# ================================================================

import requests
import pandas as pd
from datetime import datetime, timezone, timedelta


# 优先用镜像域名（国内公司网络可直连），失败后切主域名
BINANCE_KLINE_URLS = [
    "https://data-api.binance.vision/api/v3/klines",
    "https://api.binance.com/api/v3/klines",
]

# 币安的时间间隔映射
INTERVAL_MAP = {
    "15min": "15m",
    "1hour": "1h",
    "4hour": "4h",
    "1day": "1d"
}


def get_klines(symbol: str, interval: str, limit: int = 50) -> pd.DataFrame:
    """
    从币安获取K线数据
    :param symbol: 交易对，如 'btcusdt'（币安需要大写 'BTCUSDT'）
    :param interval: K线周期，如 '15min' → 映射为 '15m'
    :param limit: 获取数量，最大1000
    :return: DataFrame，列：timestamp, open, high, low, close, volume
    """
    # 转换参数格式
    binance_symbol = symbol.upper()
    binance_interval = INTERVAL_MAP.get(interval, interval.replace("min", "m"))
    
    params = {
        "symbol": binance_symbol,
        "interval": binance_interval,
        "limit": limit
    }
    try:
        last_err = None
        resp = None
        for url in BINANCE_KLINE_URLS:
            try:
                resp = requests.get(url, params=params, timeout=10)
                resp.raise_for_status()
                break
            except Exception as e:
                last_err = e
                continue
        if resp is None:
            raise last_err
        data = resp.json()

        records = []
        for item in data:
            records.append({
                "timestamp": datetime.fromtimestamp(item[0] // 1000, tz=timezone(timedelta(hours=8))),
                "open":   float(item[1]),
                "high":   float(item[2]),
                "low":    float(item[3]),
                "close":  float(item[4]),
                "volume": float(item[5]),
            })

        df = pd.DataFrame(records)
        return df

    except requests.exceptions.RequestException as e:
        print(f"[币安API错误] 获取K线失败: {e}")
        return pd.DataFrame()
    except Exception as e:
        print(f"[数据解析错误] {e}")
        return pd.DataFrame()


def get_price_change_pct(symbol: str, hours: int = 4) -> float:
    """
    获取最近N小时的价格涨跌幅（用于暴跌过滤）
    :return: 涨跌幅百分比，负数代表下跌
    """
    # 15分钟K线，4小时需要16根，加一些缓冲
    candles_needed = hours * 4 + 5
    df = get_klines(symbol, "15min", limit=candles_needed + 1)
    if df.empty or len(df) < 2:
        return 0.0

    # 计算hours小时前的价格（最近的完整K线）
    idx = min(candles_needed, len(df) - 1)
    start_price = df.iloc[-idx]["close"]
    end_price = df.iloc[-1]["close"]
    return (end_price - start_price) / start_price * 100
